#!/bin/sh


# Source tutorial run functions
. $WM_PROJECT_DIR/bin/tools/RunFunctions
#clean log file
./Allclean
# Alternative decomposeParDict name:
decompDict="-decomposeParDict system/decomposeParDict.6"
## Standard decomposeParDict name:
# unset decompDict

# copy motorbike surface from resources directory
\cp $FOAM_TUTORIALS/resources/geometry/motorBike.obj.gz constant/triSurface/
runApplication surfaceFeatureExtract

runApplication blockMesh

runApplication decomposePar $decompDict

# Using distributedTriSurfaceMesh?
if foamDictionary -entry geometry -value system/snappyHexMeshDict | \
   grep -q distributedTriSurfaceMesh
then
    runParallel $decompDict surfaceRedistributePar motorBike.obj independent
fi

runParallel $decompDict snappyHexMesh -overwrite

#- For non-parallel running: - set the initial fields
# restore0Dir

#- For parallel running: set the initial fields
restore0Dir -processor

runParallel $decompDict patchSummary
runParallel $decompDict potentialFoam
runParallel $decompDict $(getApplication)

runApplication reconstructParMesh -constant
runApplication reconstructPar -latestTime

#------------------------------------------------------------------------------
