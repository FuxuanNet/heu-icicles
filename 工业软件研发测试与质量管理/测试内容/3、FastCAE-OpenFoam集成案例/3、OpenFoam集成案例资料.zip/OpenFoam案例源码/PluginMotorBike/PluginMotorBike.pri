HEADERS += \
	$$PWD/OpenFoamPluginAPI.h \
	$$PWD/PluginOpenFoamExtend.h \
	
SOURCES += \
	$$PWD/PluginOpenFoamExtend.cpp \
	
FORMS += \

	