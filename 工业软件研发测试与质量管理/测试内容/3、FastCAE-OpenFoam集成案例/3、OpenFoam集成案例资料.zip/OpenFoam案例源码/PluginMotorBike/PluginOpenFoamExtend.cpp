﻿#include "PluginOpenFoamExtend.h"
class IOConfigure;
#include <QDebug>
#include "mainWindow/mainWindow.h"
#include "ModelData/modelDataFactory.h"
#include "ModelData/modelDataSingleton.h"
#include "ModelData/modelDataBase.h"
#include "IO/IOConfig.h"
#include <QDir>
#include <QApplication>
#include <QFile>
#include <vtkSTLWriter.h>
#include <vtkSmartPointer.h>
#include <QTextCodec>
#include "meshData/meshSingleton.h"
#include "meshData/meshKernal.h"
#include <vtkDataSet.h>
#include <QTextStream>
#include <QTextCodec>
#include "IO/SolverIO.h"
#include <QtMath>
#include <QMessageBox>
namespace GUI
{
	class MainWindow;
}
namespace Plugins
{
	
	PluginOpenFoamExtend::PluginOpenFoamExtend(GUI::MainWindow* m)
	{
		mMainWindow = m;
		_describe = "OpenFoam plugin";
	}

	bool PluginOpenFoamExtend::install()
	{
		IO::IOConfigure::RegisterInputFile("OpenFoamRollDamp", WriteOut);
		IO::IOConfigure::RegisterOutputTransfer("OpenFoamFileTrans", transfer);

		return true;
	}

	bool PluginOpenFoamExtend::uninstall()
	{
		IO::IOConfigure::RemoveInputFile("OpenFoamRollDamp");
		IO::IOConfigure::RemoveInputFile("OpenFoamFileTrans");
		return true;
	}

	GUI::MainWindow* PluginOpenFoamExtend::getMainWindow()
	{
		return mMainWindow;
	}
}

void Register(GUI::MainWindow* m, QList<Plugins::PluginBase*>* ps)
{
	//Plugins::PluginOpenFoamExtend::invalue = 1;
	Plugins::PluginBase* p = new Plugins::PluginOpenFoamExtend(m);
	ps->append(p);
}
bool  WriteOut(QString path, ModelData::ModelDataBase* d)
{
	transfer(path);
	QString filename;
	QString casepath;
	casepath = d->getPath() + "/";
	qDebug() << d->getName();
	qDebug() << "writeTest";
	QString binpath =QCoreApplication::applicationDirPath();
	QDir dir;
	QString resultpath;
	resultpath = casepath + "Result/";
	if (!dir.exists(resultpath))
	{
		bool res = dir.mkpath(resultpath);
	}
	if (!copyDirectoryFiles(binpath + "/../solver/dictionary", casepath, true))
	{
		sendMessageToConsole(QObject::tr("Copy dictionary fail,please check!"));
		return false;
	}
    if (!writeinputText((casepath + "initparameter"),d))
	{
		return false;
	}
	return true;
}
bool transfer(QString path)
{
	QStringList rowList;
	QString sourcePath = path + "/postProcessing/cuttingPlane";
	QString destPath = path + "/Result/CuttingPlane/";
	if (!transfileToDest(sourcePath, destPath, 0))
	{
		sendMessageToConsole(QStringLiteral("从PostProcessing/cuttingPlane目录复制文件到Result/cuttingPlane出错"));
		return false;
	}
	sourcePath = path + "/postProcessing/sets/streamLines/";
	destPath = path + "/Result/StreamLines/";
	if (!transfileToDest(sourcePath, destPath,1))
	{
		sendMessageToConsole(QStringLiteral("从PostProcessing/sets/streamLines目录复制文件到Result/cuttingPlane出错"));
		return false;
	}
	QString fileName = path + "/postProcessing/forceCoeffs1/0/coefficient.dat";
	QFile file_y(fileName);
	if (!file_y.exists())
	{ 
		sendMessageToConsole(QStringLiteral("postProcessing/forceCoeffs1/0/目录下，不存在coefficient.dat文件转换出错"));
		return false;
	}

	if (!file_y.open(QIODevice::ReadOnly))
		return false;
	rowList.clear();
	QString lineStr;
	while (!file_y.atEnd())
	{
		lineStr = file_y.readLine().trimmed();
		if (lineStr != "")
		{
			if (!lineStr.contains("# Time"))
			{
				continue;
			}
			lineStr = "Time       Cm           Cd           Cl           Cl(f)        Cl(r)";
			rowList.append(lineStr);
			break;
		}
	}
	while (!file_y.atEnd())
	{
		lineStr = file_y.readLine();
		lineStr = lineStr.replace("	", "   ");
		rowList.append(lineStr);
	}
	QString curFileName;
	curFileName = path + "/Result/coefficient.dat";
	QFile file(curFileName);
	if (!file.open(QIODevice::WriteOnly | QIODevice::Text))return false;
	QTextStream stream(&file);
	for (int i = 0; i < rowList.count(); i++)
	{
		stream << rowList.at(i) << endl;
	}
	return true;
}

bool OPENFOAMPLUGINAPI copyDirectoryFiles(const QString &fromDir, const QString &toDir, bool coverFileIfExist)
{
	QDir sourceDir(fromDir);
	QDir targetDir(toDir);
	if (!targetDir.exists()){    /**< 如果目标目录不存在，则进行创建 */
		if (!targetDir.mkdir(targetDir.absolutePath()))
			return false;
	}
	QFileInfoList fileInfoList = sourceDir.entryInfoList();
	foreach(QFileInfo fileInfo, fileInfoList){
		if (fileInfo.fileName() == "." || fileInfo.fileName() == "..")
			continue;
		if (fileInfo.isDir())
		{    /**< 当为目录时，递归的进行copy */
			if (!copyDirectoryFiles(fileInfo.filePath(),
				targetDir.filePath(fileInfo.fileName()), coverFileIfExist))
				return false;
		}
		else{            /**< 当允许覆盖操作时，将旧文件进行删除操作 */

			if (coverFileIfExist && targetDir.exists(fileInfo.fileName())){
				targetDir.remove(fileInfo.fileName());
			}
			/// 进行文件copy
			if (!QFile::copy(fileInfo.filePath(),
				targetDir.filePath(fileInfo.fileName()))){
				return false;
			}
		}

	}
	return true;
}


void OPENFOAMPLUGINAPI sendMessageToConsole(QString hintInfo)
{
	GUI::MainWindow* mainwindow=nullptr;
	mainwindow = Plugins::PluginOpenFoamExtend::getMainWindow();
	if (mainwindow == nullptr) return;
	ModuleBase::Message message;
	message.type = ModuleBase::MessageType::Warning_Message;
	message.message = hintInfo;
	emit mainwindow->printMessageToMessageWindow(message);
}

bool OPENFOAMPLUGINAPI writeinputText(QString filename, ModelData::ModelDataBase*d)
{

	QString splitchar = "              ";
	QString paravalue;
	QStringList list;
	QString startTime;
	QString endTime;

	paravalue = getParameterValue(QStringLiteral("开始步"), d);
	
	list.append(QStringLiteral("starttime%1%2").arg(splitchar).arg(paravalue));
	paravalue = getParameterValue(QStringLiteral("结束步"), d);
	list.append(QStringLiteral("endtime%1%2").arg(splitchar).arg(paravalue));

	paravalue = getParameterValue(QStringLiteral("求解器名称"), d);
	list.append(QStringLiteral("application%1%2").arg(splitchar).arg(paravalue));

	paravalue = getParameterValue(QStringLiteral("文件生成间隔"), d);
	list.append(QStringLiteral("writeInterval%1%2").arg(splitchar).arg(paravalue));

	//blockmesh

	DataProperty::ParameterTable* pNx = getParameterTable(QStringLiteral("各方向网格数量"), d);
	if (pNx != nullptr)
	{
		if (pNx->getRowCount() > 0 && pNx->getColumnCount() > 2)
		{
			list.append(QStringLiteral("xgridnumber%1%2").arg(splitchar).arg(pNx->getValue(0, 0)));
			list.append(QStringLiteral("ygridnumber%1%2").arg(splitchar).arg(pNx->getValue(0, 1)));
			list.append(QStringLiteral("zgridnumber%1%2").arg(splitchar).arg(pNx->getValue(0, 2)));
		}
		
	}
	int rowcount;
	DataProperty::ParameterTable* pNy = getParameterTable(QStringLiteral("顶点坐标"), d);
	if (pNy != nullptr)
	{
		rowcount = pNy->getRowCount();
		for (int i = 0; i < rowcount; i++)
		{
			double x, y, z;
			x = pNy->getValue(i, 0);
			y = pNy->getValue(i, 1);
			z = pNy->getValue(i, 2);
			list.append(QStringLiteral("x%1%2%3").arg(i + 1).arg(splitchar).arg(x));
			list.append(QStringLiteral("y%1%2%3").arg(i + 1).arg(splitchar).arg(y));
			list.append(QStringLiteral("z%1%2%3").arg(i + 1).arg(splitchar).arg(z));
		}
	}


	//decomposepardict

	DataProperty::ParameterTable* px = getParameterTable(QStringLiteral("各方向分解数量"), d);
	if (px != nullptr)
	{
		if (px->getColumnCount()> 2&&px->getRowCount()>0)
		{
			list.append(QStringLiteral("nx%1%2").arg(splitchar).arg(px->getValue(0, 0)));
			list.append(QStringLiteral("ny%1%2").arg(splitchar).arg(px->getValue(0, 1)));
			list.append(QStringLiteral("nz%1%2").arg(splitchar).arg(px->getValue(0, 2)));
		}
		
	}
	paravalue = getParameterValue(QStringLiteral("分解域的总数"), d);
	list.append(QStringLiteral("core%1%2").arg(splitchar).arg(paravalue));
	
	DataProperty::ParameterSelectable *pMethod = getParameterSelectable(QStringLiteral("分解方法"), d);
	if (pMethod != nullptr)
	{
		int index = pMethod->getCurrentIndex();
		QString methodstr;
		if (index == 0)
		{
			methodstr = "hierarchical";
		}
		else
		{
			methodstr = "ptscotch";
		}
		list.append(QStringLiteral("decomposemethod%1%2").arg(splitchar).arg(methodstr));
	}

	//snappyHexMeshDict:
	paravalue = getParameterValue(QStringLiteral("是否切割网格"), d);

	list.append(QStringLiteral("castellatedMesh%1%2").arg(splitchar).arg(paravalue));

	paravalue = getParameterValue(QStringLiteral("是否进行网格贴合"), d);

	list.append(QStringLiteral("snap%1%2").arg(splitchar).arg(paravalue));

	
	paravalue = getParameterValue(QStringLiteral("添加网格边界层"), d);

	list.append(QStringLiteral("addLayers %1%2").arg(splitchar).arg(paravalue));

	paravalue = getParameterValue(QStringLiteral("最小表面细化等级"), d);

	list.append(QStringLiteral("minlevel%1%2").arg(splitchar).arg(paravalue));

	paravalue = getParameterValue(QStringLiteral("最大表面细化等级"), d);

	list.append(QStringLiteral("maxlevel%1%2").arg(splitchar).arg(paravalue));

	paravalue = getParameterValue(QStringLiteral("边界层添加迭代数"), d);

	list.append(QStringLiteral("nLayerIter%1%2").arg(splitchar).arg(paravalue));

	//controldict


	QFile file(filename);
	if (!file.open(QIODevice::WriteOnly | QIODevice::Text))return false;
	QTextStream stream(&file);
	for (int i = 0; i < list.count(); i++)
	{
        stream << list.at(i)+";" << endl;
	}
	return true;
}

QString getParameterValue(QString paraname, ModelData::ModelDataBase*d)
{
	QString t;
	DataProperty::ParameterBase* p = d->getParameterByName(paraname);
	if (p != nullptr)
	{
		if (p->getParaType() == DataProperty::Para_String)
		{
			 t= p->valueToString();
		}
		else if (p->getParaType() == DataProperty::Para_Int)
		{
			DataProperty::ParameterInt* pInt=(DataProperty::ParameterInt*)(p);
			t = QString("%1").arg(pInt->getValue());
		}
		else if (p->getParaType() == DataProperty::Para_Double)
		{
			DataProperty::ParameterDouble* pDouble = (DataProperty::ParameterDouble*)(p);
			t = QString("%1").arg(pDouble->getValue());
		}
		else if (p->getParaType() == DataProperty::Para_Bool)
		{
			DataProperty::ParameterBool* pBool = (DataProperty::ParameterBool*)(p);
			return pBool->valueToString();
			if (pBool->getValue())
			{
				t = QString("%1").arg("true");
			}
			else
			{
				t = QString("%1").arg("false");
			}
			
		}
		return t;
	}
	else
	{
		return "0.0000";
	}
}

DataProperty::ParameterTable* getParameterTable(QString paraname, ModelData::ModelDataBase*d)
{
	DataProperty::ParameterTable* result = nullptr;
	DataProperty::ParameterBase* p = d->getParameterByName(paraname);
	if (p != nullptr)
	{
		if (p->getParaType() == DataProperty::Para_Table)
		{
			result = (DataProperty::ParameterTable*)(p);
		}
	}
	return result;
}

DataProperty::ParameterSelectable* getParameterSelectable(QString paraname, ModelData::ModelDataBase* d)
{
	DataProperty::ParameterSelectable* result = nullptr;
	DataProperty::ParameterBase* p = d->getParameterByName(paraname);
	if (p != nullptr)
	{
		if (p->getParaType() == DataProperty::Para_Selectable)
		{
			result = (DataProperty::ParameterSelectable*)(p);
		}
	}
	return result;
}

void showmsg(QString inputtext)
{
	QMessageBox msgBox;
	msgBox.setText(inputtext);
	msgBox.exec();
}

bool OPENFOAMPLUGINAPI transfileToDest(const QString &fromDir, const QString &toDir, int type)
{
	int i = 0;
	QStringList dirlist;
	QDir sourceDir(fromDir);
	sourceDir.setFilter(QDir::Dirs);
	sourceDir.setSorting(QDir::Name);
	QDir targetDir(toDir);
	if (!targetDir.exists()){    /**< 如果目标目录不存在，则进行创建 */
		if (!targetDir.mkdir(targetDir.absolutePath()))
			return false;
	}

	QString destFileName;
	QFileInfoList fileInfoList = sourceDir.entryInfoList();
	int fileno = 0;
	foreach(QFileInfo fileInfo, fileInfoList)
	{
		if (fileInfo.fileName() == "." || fileInfo.fileName() == "..")
			continue;
		QString dirname = fileInfo.filePath();
		if (fileInfo.isDir())
		{
			QDir fileDir(fileInfo.filePath());

			fileDir.setFilter(QDir::Files);

			QFileInfoList fileList = fileDir.entryInfoList();

			destFileName = "";
			
			for (int j = 0; j < fileList.count(); j++)
			{
				if (fileList.at(j).fileName() == "." || fileList.at(j).fileName() == "..") continue;
				if (type == 0)
				{
					if (fileList.at(j).fileName().contains("p_y"))
					{
						destFileName = QString("%1%2%3%4").arg(toDir).arg("p").arg(fileno).arg(".vtk");
						fileno++;
					}
				}
				else
				{
					if (fileList.at(j).fileName().contains("track0_p"))
					{
						destFileName = QString("%1%2%3%4").arg(toDir).arg("streamline").arg(fileno).arg(".vtk");
						fileno++;
					}
					
				}
				if (targetDir.exists(fileList.at(j).fileName()))
				{
					targetDir.remove(fileList.at(j).fileName());
				}
				QString filename;
				filename = fileList.at(j).filePath();
				if (!QFile::copy(fileList.at(j).filePath(), destFileName));
				{
					//return false;
				}
			}
		}
	}
		return true; 
}

