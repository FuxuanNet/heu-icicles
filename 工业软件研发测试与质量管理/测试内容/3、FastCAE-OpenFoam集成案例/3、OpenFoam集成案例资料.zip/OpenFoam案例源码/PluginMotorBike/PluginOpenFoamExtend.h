#ifndef PLUGINOPENFOAMEXTEND_H
#define PLUGINOPENFOAMEXTEND_H

#include "OpenFoamPluginAPI.h"
#include "PluginManager/pluginBase.h"
#include "DataProperty/modelTreeItemType.h"
#include "mainWindow/mainWindow.h"
#include "DataProperty/ParameterTable.h"
#include "DataProperty/ParameterSelectable.h"
#include "DataProperty/ParameterInt.h"
#include "DataProperty/ParameterBool.h"
#include "DataProperty/ParameterDouble.h"

namespace IO
{
	class SolverIO;
}
class IOConfigure;
namespace ModelData
{
	class ModelDataBase;
}
namespace GUI
{
	class  MainWindow;
}
namespace Plugins
{
	static GUI::MainWindow* mMainWindow;
	class OPENFOAMPLUGINAPI PluginOpenFoamExtend:public PluginBase
	{
		Q_OBJECT
	public:
		PluginOpenFoamExtend(GUI::MainWindow* m);
		PluginOpenFoamExtend();
		//���ز��
		bool install() override;
		//ж�ز��
		bool uninstall() override;
	public:
		static int invalue;
		static GUI::MainWindow* getMainWindow();
	private:
		//���Ϳ���̨��Ϣ
		void sendMessageToConsole(QString hint);
	signals:
		void treePrintMessageToMessageWindowSignal(ModuleBase::Message message);
	};
}
extern "C"
{
	void OPENFOAMPLUGINAPI Register(GUI::MainWindow*m, QList<Plugins::PluginBase*>*plugs);
	void showmsg(QString inputtext);
	//������ļ�д�����������ʹ��
	bool OPENFOAMPLUGINAPI WriteOut(QString path, ModelData::ModelDataBase*d);
	//�����ɺ���ļ�ת��
	bool OPENFOAMPLUGINAPI transfer(QString);
	//�����ֵ��ļ���caseĿ¼��
	bool OPENFOAMPLUGINAPI  copyDirectoryFiles(const QString &fromDir, const QString &toDir, bool coverFileIfExist);
	//��������ɺ��ƺ����ļ���case��Ŀ¼ 
	bool OPENFOAMPLUGINAPI  transfileToDest(const QString &fromDir, const QString &toDir, int type);
	//���ɽű��ļ�
	bool OPENFOAMPLUGINAPI writeScriptFile(QString filename, ModelData::ModelDataBase*d);
	//������Ϣ������̨
	void OPENFOAMPLUGINAPI sendMessageToConsole(QString hintInfo);
	//����openfoam�ֵ����ȡ���ı��ļ�
	bool OPENFOAMPLUGINAPI writeinputText(QString filename, ModelData::ModelDataBase*d);
	QString getParameterValue(QString paraname, ModelData::ModelDataBase*d);
	DataProperty::ParameterTable* getParameterTable(QString paraname, ModelData::ModelDataBase*d);
	DataProperty::ParameterSelectable* getParameterSelectable(QString paraname, ModelData::ModelDataBase* d);

}



#endif // PLUGINOPENFOAMEXTEND_H
