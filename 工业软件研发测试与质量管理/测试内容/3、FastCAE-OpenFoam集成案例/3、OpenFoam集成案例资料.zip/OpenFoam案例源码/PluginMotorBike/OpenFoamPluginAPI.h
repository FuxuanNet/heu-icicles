#ifndef _OPENFOAMPLUGINAPI_H__
#define _OPENFOAMPLUGINAPI_H__

#include <QtCore/QtGlobal>


#if defined(OPENFOAMPLUGIN_API)
#define OPENFOAMPLUGINAPI Q_DECL_EXPORT
#else
#define  OPENFOAMPLUGINAPI Q_DECL_IMPORT
#endif

#endif
